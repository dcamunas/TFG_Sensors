#include <Arduino.h>
#include <ESP8266WiFi.h>          //ESP8266 Core WiFi Library (you most likely already have this in your sketch)
#include <DNSServer.h>            //Local DNS Server used for redirecting all requests to the configuration portal
#include <ESP8266WebServer.h>     //Local WebServer used to serve the configuration portal
#include <WiFiManager.h>          //https://github.com/tzapu/WiFiManager WiFi Configuration Magic
#include <string>
#include <Ticker.h>

#define WIFI_LED_PIN D0
#define SENSOR_LED_PIN  D2
#define SENSOR_PIN  D1 
#define MONITOR_SPEED 115200
#define NAME "ESP8266-Sensor1"

/* Function declarations */
void basic_read();
void wifi_conect();

/* Global variables */
uint8_t sensor_value;
int person_number = 0;
String wifi_ip;


void setup() 
{
  Serial.begin(MONITOR_SPEED);
  pinMode(SENSOR_PIN, INPUT);
  pinMode(SENSOR_LED_PIN, OUTPUT);
  pinMode(WIFI_LED_PIN, OUTPUT);
  
  /*Wifi Manager conect */
  wifi_conect();
}

void loop() 
{
 basic_read();
}

void basic_read()
{
  sensor_value = digitalRead(SENSOR_PIN);
  digitalWrite(SENSOR_LED_PIN, sensor_value);
  if(sensor_value == HIGH)
  {
    Serial.printf("Persons in room %d\n", ++person_number);
    delay(3000);
  }
}

void wifi_conect()
{
  WiFiManager wm;
  //wm.resetSettings();

  /* Check wifi conect */
  if(!wm.autoConnect(NAME))
  {
    Serial.println("[X] Fallo de conexión, se intentará de nuevo...");
    //ESP.reset();  // Reseteo de la conexion
    delay(1000);  // Retardo de un segundo
  }

    wifi_ip = WiFi.localIP().toString();
    Serial.printf("[X] %s is conected.\n", NAME);
}


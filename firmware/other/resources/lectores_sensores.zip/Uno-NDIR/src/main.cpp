#include <Arduino.h>

const int sensor_pin = A0;

void setup()
{
  Serial.begin(9600);
  pinMode(sensor_pin, INPUT);
  //analogReference(DEFAULT);
}

void loop()
{
  // put your main code here, to run repeatedly:
  // Read voltage
  int sensor_value = analogRead(sensor_pin);
  Serial.println(sensor_value);

/* Depende si es en mv o v */
  // The analog signal is converted to a voltage
  //  V = 0,4 V - -> 2,0 V || 400mv --> 2000mv
  //float voltage = sensor_value * (5000 / 1023);
    float voltage = sensor_value * (5000.0 / 1023.0);


  if (voltage == 0)
  {
    Serial.println("Fault");
  }
  else if (voltage < 400)
  {
    Serial.println("preheating");
  }
  else
  {
    int voltage_diference = voltage - 400;
    float concentration = (voltage_diference * 50.0) / 16.0;

    // Print Voltage and concentration
    Serial.println("[X] Voltage: " + String(voltage) + " mv  ||  Concentration: " + String(concentration) + " ppm.");
  }
  delay(2000);
}
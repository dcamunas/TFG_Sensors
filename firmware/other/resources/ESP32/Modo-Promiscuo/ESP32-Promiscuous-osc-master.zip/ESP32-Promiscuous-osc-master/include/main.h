#ifndef _MAIN_H
#define _MAIN_H

#include <Arduino.h>
#include "wifi_connection.h"
#include "sensor.h"
#include "get_sensor_data.h"

#endif

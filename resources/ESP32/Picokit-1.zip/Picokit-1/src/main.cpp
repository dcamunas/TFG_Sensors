#include <Arduino.h>

void basic_read();

#define LED  2
#define SENSOR  13 
#define MONITOR_SPEED 115200

int number = 0;

void setup() 
{
  // put your setup code here, to run once:
  Serial.begin(MONITOR_SPEED);
  pinMode(SENSOR, INPUT);
  pinMode(LED, OUTPUT);
}

void loop() 
{
  // put your main code here, to run repeatedly:
  basic_read();

}

void basic_read()
{
      int read = digitalRead(SENSOR);
      if(read == HIGH)
      {
        digitalWrite(LED, read);
        Serial.printf("Value %d\n", ++number);
        delay(50);
      }
}

